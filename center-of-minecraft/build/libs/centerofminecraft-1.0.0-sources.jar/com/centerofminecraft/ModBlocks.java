package com.centerofminecraft;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {
	private static final List<class_1792> BUILDING_BLOCK_TAB_ITEMS = new ArrayList<>();

	private static final RegisteredBlock NESSIE = registerBlockWithItem(
			"nessie",
			class_4970.class_2251.method_9637().method_31710(class_3620.field_16022).method_9629(1.5F, 6.0F).method_29292()
	);
	public static final class_2248 NESSIE_BLOCK = NESSIE.block();
	public static final class_1792 NESSIE_ITEM = NESSIE.item();

	private ModBlocks() {
	}

	public static void initialize() {
		// Intentionally empty. Static init handles registration.
	}

	public static void addToBuildingBlocksTab(FabricItemGroupEntries entries) {
		BUILDING_BLOCK_TAB_ITEMS.forEach(entries::method_45421);
	}

	private static RegisteredBlock registerBlockWithItem(String path, class_4970.class_2251 properties) {
		class_2960 id = class_2960.method_60655(Centerofminecraft.MOD_ID, path);
		class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);
		class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, id);

		class_2248 block = class_2378.method_10230(
				class_7923.field_41175,
				id,
				new class_2248(properties.method_63500(blockKey))
		);

		class_1792 item = class_2378.method_10230(
				class_7923.field_41178,
				id,
				new class_1747(block, new class_1792.class_1793().method_63686(itemKey).method_63685())
		);
		BUILDING_BLOCK_TAB_ITEMS.add(item);
		return new RegisteredBlock(block, item);
	}

	private record RegisteredBlock(class_2248 block, class_1792 item) {
	}
}
